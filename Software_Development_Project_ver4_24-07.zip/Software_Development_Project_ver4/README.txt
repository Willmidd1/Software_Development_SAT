Software Development Project - README.txt
By: Will 12SDA

HOW TO RUN:
- In order to use this program run Main.py as this accesses all other modules.

VIEWING CLIENT WEBPAGES:
The client_webpages folder is a folder you can access to view example websites that a client may have.
Navigate to this folder and open the .html file to view these sites. These are the sites in which 
the python code will upload the data to. Each sub-folder under this client_webpages folder is like the
web server of a site and each webpage will reflect on its last recieved update.

IMPORTANT NOTE:
When opening/running Client_Webpage.html files to view example webpages. Make sure
to open with Microsoft Edge as file read/writing is blocked on other browsers.
Although the program will alert you if you use the wrong browser


To View Javascript / HTML Code for client webpages:
- Navigate to the webpage html
- Right click and open with any text editor
Note: The javascript and html contains internal documentation as well