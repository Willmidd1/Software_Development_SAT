
'''
SOFTWARE DEVELOPMENT PROJECT
Client Update Utility - Main Module

Made By: Will 12SDA
Started on 14/07/2020

This is the code that should be run in order to
run the program. This will initialise the GUI module
which will use the other modules.

This uses:
GUI_Module.py

'''

#Import all other required modules that I have coded
import GUI_Module

GUI_Module.initialise() #Setup the GUI using the first page as the initial page

