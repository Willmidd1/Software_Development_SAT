Software Development Project - README.txt
By: Will 12SDA

HOW TO RUN:
- In order to use this program run Main.py as this accesses all other modules.

EXAMPLES OF INPUT VALIDATION:
- line 384 of GUI_Module.py frequency input validation (Format, Existance, Type and Range Checks)
- line 466 of GUI_Module.py, validation on file names (Format and Existance Check)
- line 741 of GUI_Module.py, client name validation (Existance and Format checks, checks if name is already used)
- line 783 of GUI_Module.py, version validation (Format and Type check)
- line 845 of GUI_Module.py, remove client buttton (Type and Range Check)
- line 1180 of GUI_Module.py, email confirmation validation (Consistency Check)
- line 1220 of GUI_Module.py, update scheduler event input validation (Existence and Range Check, checks if another event is not on same date)

-----------------------------------------------------------------------------------------

EXPORTING THE UPDATE LOG:
- Choose your desired file type, when the popup opens up, select the desired folder
- The next popup asks for the file name
- Press ok and it is saved
NOTE: CSV file exports are fully compatible with excel and are intended to be opened in such a way

UPLOADING FILES:
You can press browse on the home page to upload a file, once the file is uploaded, and an
update is ran, it will distribute that file (the update data) to each client. See 'VIEWING CLIENT WEBPAGES'
on how to verify that that file was uploaded.

-----------------------------------------------------------------------------------------

VIEWING CLIENT WEBPAGES:
The client_webpages folder is a folder you can access to view example websites that a client may have.
Navigate to this folder and open the .html file to view these sites. These are the sites in which 
the python code will upload the data to. Each client_webpages folder is like the web server of a site
and each webpage will reflect on its last recieved update and will show the file it has recieved as update
data.

To View Javascript / HTML Code for client webpages:
- Navigate to the webpage html
- Right click and open with any text editor
Note: The javascript and html contains internal documentation as well

---------------------------------------------------------------------------------------

ERROR HANDLING
If you ever get a PermissionError from a python output:
- Please run the program as administrator to fix any permission errors being outputted

If the HTML Webpage has "Access Denied" on the page:
- Try running edge as administrator. This worked on my PC, but has not been working at school possibly due to permissions



End of README.txt