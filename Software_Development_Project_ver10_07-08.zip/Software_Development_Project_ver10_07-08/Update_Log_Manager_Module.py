'''
SOFTWARE DEVELOPMENT PROJECT
Client Update Utility - Update_Log_Manager.py

Made By: Will 12SDA
Started on 30/07/2020

This module contains the code to draw to, update,
filter and sort the update log in the GUI with
respects to any new updates.

Naming Conventions: Camel Case

This uses:
GUI_module.py

'''
#Import Dependencies
from datetime import datetime

#Import modules I created
import GUI_Module as gui

arrUpdateLogLines = ["","UPDATE LOG"] #Array of lines in the update log, preloaded with title lines
arrRawData = [] #An array to store the unformatted data from the log. This is used for sorting the log
currentUpdate = 0 #A counter to keep track of how many updates have happened
isDateFiltered,isNameFiltered, isStatusFiltered = False, False, False #Setting three variables to false for determining which type of sort is active 

#---------------------------------------------------------------------------------------------------

def addToUpdateLog(clients, version):
    '''
    This function is called from other modules after an update has occured.
    It creates and formats the update log for it to be drawn to the GUI. It
    takes an array of clients and the current version as arguments.
    '''
    global currentUpdate #Use global counter variable
    
    currentUpdate += 1 #Increment update counter as a new update has occured

    arrUpdateLogLines.append("") #Insert a blank line
    arrUpdateLogLines.append("Cumulative Update " + str(currentUpdate) + ":") #Show which update it is in a subheading


    for client in clients: #Loop thourh all given clients

        #Display name and timestamp of attempted update
        arrUpdateLogLines.append("")
        arrUpdateLogLines.append("> Client Name: " + client.name[3:len(client.name)])
        time = datetime.now() #Get the current time as the timestamp
        arrUpdateLogLines.append("> Timestamp: " + time.strftime("%d/%m, %H:%M:%S"))

        #Find out whether the client recieved an update or not
        outcome = ""
        if client.active: #If the client has been turned on in the list
            outcome = "SUCCESS" #Set the status to a success
        else:
            outcome = "CLIENT IS DISABLED IN LIST" #Add a note to notify user that they have disabled the client

        if client.info != "": #If there is other information, such as the client is already up to date or there was a fail, set it here. This is stored in the client object
            outcome = client.info
            
        arrUpdateLogLines.append("> Success/Fail: " + outcome) #Display the outcome

        arrRawData.append([client.name[3:len(client.name)],time,outcome]) #add the data for this client to another array so it can be filtered
        
    arrUpdateLogLines.append("") #Insert blank line

    gui.drawUpdateLog(arrUpdateLogLines, True) #Draw the new lines to the GUI update log


#---------------------------------------------------------------------------------------------------

#QUICK SORT ALGORITHM IMPLEMENTATION - Used for sorting
    
def swap(arr, i1, i2):
    '''
    This is the 'swap' function which will swap any two items within an array
    '''
    temp = arr[i1] #Assign the value of item 1 to a temporary stoarage variable
    arr[i1] = arr[i2] #Make the first item the value of the second
    arr[i2] = temp #Set the second to first items value
    return arr


def quicksort(arr, low, high, item):
    '''
    Main recursive quicksort function
    '''
    pivot = arr[high] #Create the pivot for the sort
    
    if low < high: #Only continue if the low pointer is left of the high pointer
        split = low #Assign 'low' to a 'split' pointer variable for comparison within the loop

        for x in range(low, high): #Loop through this section of the array
            if item == 1: #Sort it like this for a timestamp sort
                if arr[x][item] > pivot[item]: #Compare the array items to the pivot using ">" rather than "<" to sort the array from high to low instead of low to high
                    arr = swap(arr, split, x) #Swap these items to make all items larger than pivot on one side and items smaller on the other
                    split = split + 1 #Increment the pointer
            elif item == 0:
                if arr[x][item].lower() < pivot[item].lower(): #Sort alphabetically by converting to ascii
                    arr = swap(arr, split, x) #Swap these items to make all items larger than pivot on one side and items smaller on the other
                    split = split + 1 #Increment the pointer

        arr = swap(arr, split, high) #Swap these items
        
        #Recursively call quicksort on each half of the pivot until sorted
        quicksort(arr, low, split-1, item) 
        quicksort(arr, split+1, high, item)


#---------------------------------------------------------------------------------------------------

def formatLog():
    '''
    Function for formatting a filtered log so it can be displayed
    '''
    arrOutput = [] #Output array to be returned
        
    #Format and display the output
    arrOutput.append("")
    arrOutput.append("UPDATE LOG - Filtered") #Add a title
    
    for data in arrRawData: #Loop through the raw data, this array is what gets sorted
        arrOutput.append("") #Add blank line
        arrOutput.append("> Client Name: " + data[0]) #Show client name
        arrOutput.append("> Timestamp: " + data[1].strftime("%d/%m, %H:%M:%S")) #Display the timestamp
        arrOutput.append("> Success / Fail: " + data[2]) #Display the outcome
    arrOutput.append("") #Add blank line

    return arrOutput #Return it so it can be used

#---------------------------------------------------------------------------------------------------

def filterDate():
    '''
    Function to filter log by date
    '''
    global isDateFiltered,isNameFiltered,isStatusFiltered #Access global boolean varaibles
    
    if len(arrUpdateLogLines) > 2: #If the number of lines is more than 2. Since the first 2 lines are title lines this is checking whether the log is empty or not
        if not isDateFiltered: #Only filter if it is not already filtered
            
            quicksort(arrRawData, 0, len(arrRawData)-1, 1) #Quicksort the array on the dates

            arrOutput = formatLog() #Format the now sorted array so it can be displayed

            gui.drawUpdateLog(arrOutput, False) #Draw it to the GUI

            #Set other values so you can filter using other buttons
            isDateFiltered = True
            isNameFiltered = False
            isStatusFiltered = False
        else:
            #If it is already filtered, and you press the button, draw it back to the unfiltered log
            gui.drawUpdateLog(arrUpdateLogLines, True) #Draw to GUI

            #Set other values to false
            isDateFiltered = False
            isNameFiltered = False
            isStatusFiltered = False

#---------------------------------------------------------------------------------------------------

def filterName():
    '''
    Function to filter log by client's name
    '''
    global isDateFiltered,isNameFiltered,isStatusFiltered #Access global boolean varaibles
    
    if len(arrUpdateLogLines) > 2: #If the number of lines is more than 2. Since the first 2 lines are title lines this is checking whether the log is empty or not
        if not isNameFiltered: #Only filter if it is not already filtered
            
            quicksort(arrRawData, 0, len(arrRawData)-1, 0) #Quicksort the array on the client names
            
            arrOutput = formatLog() #Format the now sorted array so it can be displayed

            gui.drawUpdateLog(arrOutput, False) #Draw it to the GUI

            #Set other values so you can filter using other buttons
            isNameFiltered = True
            isDateFiltered = False
            isStatusFiltered = False
        else:
            #If it is already filtered, and you press the button, draw it back to the unfiltered log
            gui.drawUpdateLog(arrUpdateLogLines, True) #Draw to GUI
            
            #Set other values to false
            isDateFiltered = False
            isNameFiltered = False
            isStatusFiltered = False

#---------------------------------------------------------------------------------------------------

#Function to filter the log by whether it was a success, fail or any other scenario
def filterStatus():
    '''
    Function to filter the log by the status of the update
    '''
    global isDateFiltered,isNameFiltered,isStatusFiltered, arrRawData #Access global variables
    
    if len(arrUpdateLogLines) > 2:#If the number of lines is more than 2. Since the first 2 lines are title lines this is checking whether the log is empty or not
        if not isStatusFiltered: #Only filter if it is not already filtered

            '''
            We cannot use a traditional sorting algorithm here as we need to sort in the order:
            fail, already up to date, disabled, success.
            In this order the user can see the ones that went wrong
            '''
            
            arrSorted = [] #Set an output array to empty

            for i in range(0,4): #loop through 4 times for each case
                for data in arrRawData: #loop through all the data
                    if i == 0 and data[2] == "FAIL": 
                        arrSorted.append(data) #Append all fails to front of list
                    elif i == 1 and data[2] == "ALREADY UP-TO-DATE":
                        arrSorted.append(data) #Append up to date clients next
                    elif i == 2 and data[2] == "CLIENT IS DISABLED IN LIST":
                        arrSorted.append(data) #Then the disabled clients
                    elif i == 3 and data[2] == "SUCCESS":
                        arrSorted.append(data) #Lastly the successful clients
                        
            arrRawData = arrSorted #Set the raw data array to the sorted one
            
            arrOutput = formatLog() #Format the log to be displayed

            gui.drawUpdateLog(arrOutput, False) #Draw to the gui module

            #Set other values so you can filter using other buttons
            isStatusFiltered = True
            isDateFiltered = False
            isNameFiltered = False
        else:
            #If it is already filtered, and you press the button, draw it back to the unfiltered log
            gui.drawUpdateLog(arrUpdateLogLines, True) #Draw to the GUI
            
            #Set other values to false
            isDateFiltered = False
            isNameFiltered = False
            isStatusFiltered = False

#---------------------------------------------------------------------------------------------------

#The function to format an excel-compaitble CSV file from the update log
def formatCSV():
    '''
    Function to format the lines of the update log to a CSV which
    can be read by excel
    '''
    
    arrOutputLines = ["Client Name,Update Date, Update Time, Update Status"] #set array with header line
    
    for data in arrRawData: #Loop through raw datta
        arrOutputLines.append(data[0] + "," + data[1].strftime("%d/%m, %H:%M:%S") + "," + data[2]) #Write each line of the CSV using the raw data

    return arrOutputLines #Return the output

    
#---------------------------------------------------------------------------------------------------

#END OF UPDATE LOG MANAGER MODULE
        
