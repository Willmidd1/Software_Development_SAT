'''
SOFTWARE DEVELOPMENT PROJECT
Client Update Utility - Automatic_Updates_Module.py

Made By: Will 12SDA
Started on 29/07/2020

This code contains the functionality for automatic/timed
updates of data to the clients. it also handles update events
from scheduled updates

Naming Conventions: Camel Case

This uses:
Data_Management_Module.py
GUI_Module.py
Update_Log_Manager_Module.py

'''

#Import dependencies
from datetime import datetime  
from datetime import timedelta
import time
import smtplib
import threading
from tkinter import messagebox

#Import Modules I created
import Data_Management_Module as data_manager
import GUI_Module as gui
import Update_Log_Manager_Module as update_log

#Global variables to store status of updates and frequency
isPaused = True #Whether or not the auto-updates are paused
updateFrequency = "" #How frequent the updates are (hh:mm)
versionTXT = open("data/current-update-version.txt","r") #Load in the current version
version = float(versionTXT.read()) #set the current update version to a variable
versionTXT.close() #Close the file
userEmail = open("data/user-email.txt","r").read() #Store the users email
arrEvents = [] #Array of calendar update event objects


#---------------------------------------------------------------------------------------------------

def calculateNextUpdate():
    '''
    Function to calculate exact time of the next update with the given
    frequency of auto-update
    '''
    
    data = updateFrequency.split(":") #Get info from inputted update frequency
    newDate = datetime.now() + timedelta(hours=int(data[0]),minutes=int(data[1]),seconds=int(data[2])) #Add the current datetime to the inputted frequency

    #Format the next update's date so it can be displayed
    month = str(newDate.month) #Get the month of the datetime
    day = str(newDate.day) #Get the day
    hour = str(newDate.hour) #Get the hour
    minute = str(newDate.minute) #Get the minute

    #Add zeroes in front of values less than ten so it appears nice on the GUI
    if int(month) < 10:
        month = "0" + month
    if int(day) < 10:
        day = "0" + day
    if int(hour) < 10:
        hour = "0" + hour
    if int(minute) < 10:
        minute = "0" + minute

    #Format it appropriately
    newDate = day + "/" + month + " " + hour + ":" + minute
    return newDate #Return the outputted date

#---------------------------------------------------------------------------------------------------


#This is the main loop which accounts for automatic updates
def runUpdateLoop(clients):
    '''
    This is the main loop which accounts for automatic updates. It is a loop
    which runs in order to automatically update the clients. This function is
    called by a multithreading process so that it can run as an independent
    process in order to not halt the rest of the modules
    '''
    
    global version #Use global variable for version
    
    data = updateFrequency.split(":") #Get info from inputted update frequency
    delay = timedelta(hours=int(data[0]),minutes=int(data[1]),seconds=int(data[2])).total_seconds() #Set the delay (in seconds) for how frequent the loop should repeat
    
    while isPaused == False: #Only run the loop if it isnt paused
        
        time.sleep(delay) #Wait out the delay
        
        version += 0.1 #This is a new version/update, reflect it here
        
        versionTXT = open("data/current-update-version.txt","r+") #Open up the text file to save version
        versionTXT.write(str(version)[0:3]) #Save the version
        versionTXT.close() #Close the file
        
        data_manager.distributeUpdates(clients, str(version)[0:3]) #Using 'Data_Management_Module.py', distribute an update to each client
        gui.setMostRecentUpdateText() #Set the most recentt update text in the GUI as a new update has been conducted
        update_log.addToUpdateLog(clients, str(version)[0:3]) #Add the clients to the update log



#---------------------------------------------------------------------------------------------------

class updateEvent:
    '''
    This is the CLASS for a scheduled update event from the update scheduler.
    It stores information for this event and manages its own while loop to check
    whether the event needs to be executed
    '''
    
    def __init__(self, clients, date, emailReminders):
        self.clients = clients #store clients this event applies
        self.date = date #Store the date of this event
        self.emailReminders = emailReminders #Whether or not email reminders are on
        self.wasEmailSent = False #This is to test whether an email has been sent
        self.active = True #if this event is currently active

        gui.createEvent(self.date,self.clients,self.emailReminders) #Create an event in the GUI for this update


    def checkUpdate(self):
        '''
        This checks if its time for this evnet to be executed
        '''
        #Compare the current date to the date of the scheduled events
        if datetime.now().month == self.date.month and datetime.now().day == self.date.day and datetime.now().year == self.date.year:
            #It is time for an update, return True
            return True
        else:
            return False #Return false as it is not time for the event to be executed


    def runEventLoop(self):
        '''
        Function to run an event loop to check whether an update should
        be distributed, thus executing this event. The loop checks every hour
        if it is the date of the update. This is a multithreading process function
        as it needs to be run in an independent process to not halt the program
        '''
        global version, arrEvents #Use global variables

        #Main while loop to check for a scheduled update
        while self.active: #Only while this event is active
            
            #Check if it is one day prior to the update, if so, send email to remind them, only if email reminders are active
            if datetime.now().month == self.date.month and datetime.now().day == self.date.day - 1:
                if self.emailReminders: #Only if the reminders are turned on
                    if not self.wasEmailSent: #Check this to only send the email once

                        #loop through the clients and store their names in a string to display on the email
                        clientsNames = ""
                        for client in self.clients:
                            if self.clients.index(client) < len(self.clients) - 1:
                                clientsNames = clientsNames + client.name[3:len(client.name)] + ", " #Add a comma as it is not the last line
                            else:
                                clientsNames = clientsNames + client.name[3:len(client.name)] #It is the last item in the array, no comma needed
                                
                        #Set the email's content, this is what will be sent
                        emailContent = "Subject: UPDATE REMINDER:\nThere is a scheduled update TOMMOROW ("+self.date.strftime("%d/%m/%y")+"), to the following clients:\n" + clientsNames + "\n\nThis was an automated email. Please access the client updating utility to cancel/view this update event."

                        #Send an email to the user to remind them of the update
                        mail = smtplib.SMTP('smtp.gmail.com',587) #Access the server
                        mail.ehlo()
                        mail.starttls()
                        mail.login('python.updating.utility@gmail.com','PythonUpdater123') #Log in to gmail
                    
                        mail.sendmail('python.updating.utility@gmail.com',userEmail,emailContent) #send the email to the users entered email
                        mail.close() #Close the mail SMTP server
    
                        self.wasEmailSent = True #The email was sent, set this to True so it does not send again


            
            if self.checkUpdate() == True: #Check if it is update day
                #It is the day of the update, run an update to the client using the data_management module
                version += 0.1 #This is a new version/update, reflect it here
        
                versionTXT = open("data/current-update-version.txt","r+") #Open up the text file to save version
                versionTXT.write(str(version)[0:3]) #Save the version
                versionTXT.close() #Close the text file
                    
                data_manager.distributeUpdates(self.clients, str(version)[0:3]) #Using 'Data_Management_Module.py', distribute an update to each client
        
                gui.setMostRecentUpdateText() #Set the text in the GUI to display the most recent update
                update_log.addToUpdateLog(self.clients, str(version)[0:3]) #Add the clients to the update log

                messagebox.showinfo(title="Scheduled Update",message="A scheduled update event was run.") #Show the user that an update was ran
                
                self.active = False #This event has been ran, set active to false so it wont run again
                
                #Remove from local array, the event is no longer needed
                arrEvents.pop(arrEvents.index(self))

                #Remove from the array in gui module
                day = self.date.day
                for panel in gui.arrDatePanels: #Loop through all the calendar panels
                    if day == gui.arrDatePanels.index(panel)+1: #If the panel has an event on it (The day for this event = the day on this panel)
                        gui.arrDatePanels[gui.arrDatePanels.index(panel)].resetFrame() #Remove this event from the calendar GUI as it is no longer needed
                
            time.sleep(3600) #Check once an hour for whether this event should be ran (3600 seconds)

        
#---------------------------------------------------------------------------------------------------
