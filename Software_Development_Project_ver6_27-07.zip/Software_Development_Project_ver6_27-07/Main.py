
'''
SOFTWARE DEVELOPMENT PROJECT
Client Update Utility - Main Module

Made By: Will 12SDA
Started on 14/07/2020

This code contains the main content that uses all other modules
to combine them into this one functioning program. This is the
code that needs to be run in order for the program to work

This uses:
GUI_Module.py

'''


#Import all other required modules that I have coded
import GUI_Module

GUI_Module.initialise() #Setup the GUI using the first page as the initial page
