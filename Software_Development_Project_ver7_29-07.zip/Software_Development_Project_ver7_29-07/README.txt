Software Development Project - README.txt
By: Will 12SDA

HOW TO RUN:
- In order to use this program run Main.py as this accesses all other modules.

VIEWING CLIENT WEBPAGES:
The client_webpages folder is a folder you can access to view example websites that a client may have.
Navigate to this folder and open the .html file to view these sites. These are the sites in which 
the python code will upload the data to. Each sub-folder under this client_webpages folder is like the
web server of a site and each webpage will reflect on its last recieved update.

IMPORTANT NOTE:
When opening/running Client_Webpage.html files to view example webpages. Make sure
to open with Microsoft Edge as file read/writing is blocked on other browsers.
Although the program will alert you if you use the wrong browser

TO TEST FILE UPLOADING:
Press browse and select a file. A good test could be to select this README.txt file, upload it
and run a manual update. Although any txt or csv file will work fine

To View Javascript / HTML Code for client webpages:
- Navigate to the webpage html
- Right click and open with any text editor
Note: The javascript and html contains internal documentation as well

If you ever get a PermissionError from a python output:
- Please run the program as administrator to fix any permission errors being outputted

If the HTML Webpage has "Access Denied" on the page:
- Try running edge as administrator. This worked on my PC, but has not been working at school possibly due to permissions