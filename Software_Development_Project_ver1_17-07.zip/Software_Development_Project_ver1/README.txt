Software Development Project - README.txt
By: Will 12SDA

HOW TO RUN:
- In order to use this program run GUI-Module.py

